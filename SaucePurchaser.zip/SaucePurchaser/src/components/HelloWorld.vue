<script setup>
import { ref } from 'vue'

defineProps({
  msg: String,
})

const chick_fil_a_count = ref(0)
const taco_bell_count = ref(0)
const hidden_valley_count = ref(0)

const chick_fil_a_count_stored = ref(0)
const taco_bell_count_stored = ref(0)
const hidden_valley_count_stored = ref(0)

</script>

<template>
  <h1>{{ msg }}</h1>

  <div class="card">
    <p>Chick Fil A Sauce
    <button type="button" @click="chick_fil_a_count--">- </button>
    <button type="button" @click="chick_fil_a_count++">+ </button>
    {{ chick_fil_a_count }}</p>
  </div>

  <div class="card">
    <p>Taco Bell Sauce
    <button type="button" @click="taco_bell_count--">- </button>
    <button type="button" @click="taco_bell_count++">+ </button>
    {{ taco_bell_count }}</p>
  </div>

  <div class="card">
    <p>Hidden Valley Ranch
    <button type="button" @click="hidden_valley_count--">- </button>
    <button type="button" @click="hidden_valley_count++">+ </button>
    {{ hidden_valley_count }}</p>
  </div>


  <div class="card">
    <button type="button" @click="hidden_valley_count_stored = hidden_valley_count, taco_bell_count_stored=taco_bell_count, chick_fil_a_count_stored = chick_fil_a_count, hidden_valley_count = 0, taco_bell_count=0,chick_fil_a_count =0 ">submit </button>
    <p>Last Order Totals</p>
    <p>hidden valley sauce: {{ hidden_valley_count_stored }}</p> 
    <p>taco bell sauce: {{ taco_bell_count_stored }}</p> 
    <p>chick fil a sauce: {{ chick_fil_a_count_stored }} </p>
  </div>


</template>

<style scoped>
.read-the-docs {
  color: #888;
}
</style>
